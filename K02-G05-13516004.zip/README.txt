------------------- HOW TO COMPILE ---------------------

!-- DEMI KENYAMANAN, MOHON GUNAKAN OS BERBASIS LINUX --!

- MAIN PROGRAM
>> gcc mesinkar.c mesinkata.c jam.c queuelist.c command.c MatriksMap.c unit.c pcolor.c point.c listdpUnit.c player.c stackt.c save.c load.c main.c

- DRIVER ADT JAM
>> gcc jam.c jamMain.c

- DRIVER ADT LIST DOUBLE POINTER
>> gcc point.c listdpUnit.c listdpUnitMain.c 

- DRIVER LOAD
>> gcc mesinkar.c mesinkata.c jam.c queuelist.c load.c command.c MatriksMap.c unit.c pcolor.c point.c listdpUnit.c player.c stackt.c save.c loadMain.c

- DRIVER MESIN KATA
>> gcc mesinkar.c mesinkata.c mesinkataMain.c

- DRIVER POINT
>> gcc point.c pointMain.c

- DRIVER QUEUELIST
>> gcc point.c queuelist.c queuelistMain.c 

- DRIVER SAVE
>> gcc mesinkar.c mesinkata.c jam.c queuelist.c command.c MatriksMap.c unit.c pcolor.c point.c listdpUnit.c player.c stackt.c save.c saveMain.c 

- DRIVER STACK
>> gcc point.c stackt.c stacktMain.c 

- DRIVER UNIT
>> gcc point.c unit.c unitMain.c